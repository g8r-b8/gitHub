import java.lang.Integer;

public class Runner<T>{


public static void main(String[] args){


Stack<Integer> stack = new Stack<Integer>();

Integer a=(Integer)6;
stack.push(a);


System.out.println(stack.pop());

SLL sll = new SLL();

sll.add("a");

sll.add("a");
sll.add(a);

sll.remove("a");

System.out.println(sll.size());
System.out.println(sll.getNthFromLast(0));
System.out.println(sll.getNthFromFirst(0));


//ConverterV3 cc = new ConverterV3();

//System.out.println("flag");

//String ans = cc.convert("a+b*c-d");

//System.out.println(ans);

}


}

































