Wingate Jones

wbjones@uno.edu

Was unable to get the infix to postfix converter working properly. I do include the source code for the converter despite this to show the method I put the most work into. Gets all the way to the minus sign and then hangs. Placed flags, which are still in the code, to try and determine the source of the issue.

Runner shows implementation of stack and singly linked list implementaitons, and that the various methods function accordingly. If I can provide more examples please let me know. 

Thank you again for your advice concerning this assignment.
