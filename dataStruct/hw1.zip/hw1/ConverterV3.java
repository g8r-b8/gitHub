public class ConverterV3{

public ConverterV3(){}


        public boolean isOp(char c){

                boolean bool = false;

                if(c=='+'||c=='-'||c=='/'||c=='*'||c=='('||c==')'){
                        bool = true;
                }

                return bool;

        }

        public int priority(char op){
                /*
                if (op1 == '+' || op1 == '-'){
                        return !(op2 == '+'|| op2 == '-');
                }
                        
                if (op1 == '*' || op1 == '/'){
                        return (op2 == '*'|| op2 == '/');
                }
                if(op1=='('){return true;}

                return false;
                */


                switch(op){
                        case '+':
                        case '-':
                                return 1;
                        case '*':
                        case '/':
                                return 2;
                        case '^':
                                return 3;
                }return -1;
        }

        public String convert(String infix){

                Stack<Character> stack = new Stack<Character>();
                String postfix = "";
                char[] charAr = infix.toCharArray();
                for(char c : charAr){

System.out.println(1);

                        if(!isOp(c)){
                                postfix+=c;
                                System.out.println(postfix);
                        }
                        else if (c == '('){stack.push(c);}
                        else if (c==')'){
                                while(!stack.isEmpty() && stack.charPeek() != '('){
                                        postfix += stack.pop();
System.out.println(2);
System.out.println(postfix);
                                }
                                
                                if(!stack.isEmpty()){stack.pop();}
                        }
                        else if(isOp(c)){
                                if(!stack.isEmpty() && priority(c)<= priority(stack.charPeek())){
                                     
					Character pop = stack.pop();
					if(c!='('){
						postfix += stack.pop();
						
					}else{pop=c;}
System.out.println(postfix);
                                }else
                                stack.push(c);
				
                        }
                }
                while(!stack.isEmpty()){
                        postfix += stack.pop();
System.out.println(3);
System.out.println(postfix);
                }
                return postfix;
        }

}
                        
