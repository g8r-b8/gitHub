public class SLL<T>{

	public class Node<T>{
		public T info;
	
		public Node(T info){
		
			info = this.info;
		
		}

		public void set(T newData){
		
		info = newData;
		
		}


	}


	public SLL(){
	
	
	}

	public <T> void getter(){
	
	}
	
	public static void main(String[] args){
	
	
	}

}
